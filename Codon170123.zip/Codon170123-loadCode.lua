local g = golly()
local function loadCode (istr)
	local __dectab = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 36, 38, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 0, 0, 39, 0, 0, 0, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 0, 0, 0, 0, 37, 0, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 0, 0, 0, 39, 0}
	local slen = istr:len()
	local ipos = 0
	local _rep = 1
	local flag, tstate
	local k1, k2, k3
	local offs = 0
	while ipos < slen do
		k1 = __dectab[istr:byte(ipos + 1)]
		-- Lua 没有 switch 语句.
		if (k1 < 28) then
			tstate = k1
			flag = true
		elseif (k1 < 35) then
			_rep = k1 - 26
			k2 = __dectab[istr:byte(ipos + 2)]
			if (k2 >= 28 and k2 < 37) then
				_rep = k2 - 37 + _rep * 9
				ipos = ipos + 1
			end
			flag = false
		elseif (k1 == 35) then
			_rep = 72 + __dectab[istr:byte(ipos + 2)]
			ipos = ipos + 1
			flag = false
		elseif (k1 == 37) then
			tstate = 28 + __dectab[istr:byte(ipos + 2)]
			ipos = ipos + 1
			flag = true
		elseif (k1 == 36) then
			_rep = 0
			tmp = __dectab[istr:byte(ipos + 2)]
			ipos = ipos + 2
			while (tmp >= 20) do
				_rep = (_rep + tmp - 19) * 20
				tmp = __dectab[istr:byte(ipos + 1)]
				ipos = ipos + 1
			end
			_rep = (_rep + tmp) * 40 + __dectab[istr:byte(ipos + 1)] + 112;
			flag = false
		end
		if (flag) then
			while (_rep > 0) do
				g.setcell((offs % 128) - 64, math.floor(offs / 128) - 64, tstate)
				offs = offs + 1
				_rep = _rep - 1
			end
			_rep = 1
		end
		ipos = ipos + 1
	end
	while (offs < 16384) do
		g.setcell((offs % 128) - 64, math.floor(offs / 128) - 64, 0)
		offs = offs + 1
	end
end

loadCode( g.getstring("Enter code:") )
