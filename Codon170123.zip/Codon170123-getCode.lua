local g = golly()
local function getCode ()
	local __enctab = "0123456789abcdefghijklmnopqrstuvwxyz-_.="
	function enc1 (sta)
		if (sta < 28) then
			return __enctab:sub(sta + 1, sta + 1);
		end
		return "_" .. __enctab:sub(sta - 27, sta - 27);
	end
	function enc2 (_rep)
		local last, tmp;
		if (_rep < 2) then return "" end
		if (_rep < 9) then return __enctab:sub(_rep + 27, _rep + 27) end
		if (_rep < 72) then
			tmp = math.floor(28 + _rep / 9)
			return __enctab:sub(tmp, tmp) .. __enctab:sub(29 + _rep % 9, 29 + _rep % 9);
		end
		if (_rep < 112) then return "z" .. __enctab:sub(_rep - 71, _rep - 71) end
		_rep = _rep - 112
		tmp = _rep % 40
		last = __enctab:sub(tmp + 1, tmp + 1)
		_rep = (_rep - tmp) / 40;
		tmp = _rep % 20
		last = __enctab:sub(tmp + 1, tmp + 1) .. last;
		while (_rep >= 20) do
			_rep = (_rep - tmp) / 20 - 1
			tmp = _rep % 20
			last = __enctab:sub(tmp + 21, tmp + 21) .. last;
		end
		return "-" .. last;
	end
	local str1 = ""
	local sta = g.getcell(-64, -64)
	local _rep = 0
	local i
	local j
	for i = 0, 16383 do
		j = g.getcell((i % 128) - 64, math.floor(i / 128) - 64)
		if (sta == j) then _rep = _rep + 1
		else
			str1 = str1 .. enc2 (_rep) .. enc1 (sta);
			_rep = 1;
			sta = j;
		end
	end
	if (sta ~= 0) then
		str1 = str1 .. enc2 (_rep) .. enc1 (sta);
	end
	return str1;
end

g.getstring("Output code:", getCode ())